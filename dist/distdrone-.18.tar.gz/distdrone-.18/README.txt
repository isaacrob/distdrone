This is much of the backbone for my, Isaac Robinson's, high school science project.
Although it may not seem like it, almost a year of work has gone into this.
The idea is that a drone swarm where the drones work together to process difficult tasts, 
such as image processing, will be much more efficient, especially if that task has 
a certain threshold beyond which it becomes relevant. Here, that task is facial detection
and soon-to-be facial recognition. 
I have also designed several search algorithms with which a drone swarm may search an area.
This package uses OpenCV and IPython to do its image processing and parallel computing,
respectively.
As this package is still in its basic development phases, I am not going to go into much 
detail here. If you have questions, email me at isaacrob@me.com.
This does not currently support other people, ie it is tailored to the way I've set things
up on my various computers.