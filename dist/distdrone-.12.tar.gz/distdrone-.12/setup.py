from setuptools import setup

setup(name="distdrone",
	version=".12",
	description="package to drive parallel drone swarm",
	url="http://github.com/isaacrob/paradrone",
	author="Isaac Robinson",
	author_email="isaacrob@me.com",
	license="MIT",
	packages=["distdrone","distdrone.motion"],
	#install_requires=['cv2','IPython','zmq','os','sys','scipy','numpy','time','copy','cPickle','math'],
	zip_safe=False)
