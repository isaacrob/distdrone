from setuptools import setup

setup(name="distdrone",
	version=".8",
	description="package to drive parallel drone swarm",
	url="http://github.com/isaacrob/paradrone",
	author="Isaac Robinson",
	author_email="isaacrob@me.com",
	license="MIT",
	packages=["distdrone"],
	zip_safe=False)
