from .text import testme2

def testme():
	return "YES THIS WORKS"
