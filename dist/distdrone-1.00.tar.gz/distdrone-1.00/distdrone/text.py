def testme2():
	return "THIS ALSO WORKS"