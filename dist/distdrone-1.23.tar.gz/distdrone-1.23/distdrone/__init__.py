from .text import testme2
#from .imgproc import *

def testme():
	return "YES THIS WORKS"
