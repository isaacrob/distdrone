from .text import testme2
from .imgproc import *
from .motion import *

def testme():
	return "YES THIS WORKS"
